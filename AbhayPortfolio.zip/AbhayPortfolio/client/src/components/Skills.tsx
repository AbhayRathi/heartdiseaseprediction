import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Code, Database, Cpu, Globe, Mail, Phone, Linkedin, Github } from "lucide-react";
import { ScrollAnimation, StaggerContainer, StaggerItem } from "@/components/ScrollAnimations";

interface SkillCategory {
  title: string;
  icon: React.ReactNode;
  skills: string[];
}

const skillCategories: SkillCategory[] = [
  {
    title: "Languages & Frameworks",
    icon: <Code className="w-6 h-6" />,
    skills: ["JavaScript", "TypeScript", "Python", "React.js", "Node.js", "Express", "FastAPI", "Next.js"]
  },
  {
    title: "AI/ML & Data",
    icon: <Cpu className="w-6 h-6" />,
    skills: ["Machine Learning", "NLP", "Computer Vision", "LangChain", "OpenAI API", "TensorFlow", "PyTorch", "FAISS"]
  },
  {
    title: "Databases & Cloud",
    icon: <Database className="w-6 h-6" />,
    skills: ["MongoDB", "PostgreSQL", "Pinecone", "AWS", "Docker", "GitHub CI/CD", "Vercel", "Uvicorn"]
  },
  {
    title: "Tools & Design",
    icon: <Globe className="w-6 h-6" />,
    skills: ["Git", "AutoDesk Fusion 360", "ANSYS", "MATLAB", "Figma", "CAD", "SimFlow", "A/B Testing"]
  }
];

const contactInfo = [
  {
    icon: <Mail className="w-5 h-5" />,
    label: "Email",
    value: "mr.asrathi@gmail.com",
    link: "mailto:mr.asrathi@gmail.com"
  },
  {
    icon: <Phone className="w-5 h-5" />,
    label: "Phone",
    value: "(925) 804-5462",
    link: "tel:+19258045462"
  },
  {
    icon: <Linkedin className="w-5 h-5" />,
    label: "LinkedIn",
    value: "linkedin.com/in/abhay-rathi",
    link: "https://linkedin.com/in/abhay-rathi"
  },
  {
    icon: <Github className="w-5 h-5" />,
    label: "GitHub",
    value: "github.com/AbhayRathi",
    link: "https://github.com/AbhayRathi"
  }
];

export default function Skills() {
  return (
    <section className="py-24 px-4 bg-background" id="skills">
      <div className="max-w-6xl mx-auto">
        <ScrollAnimation>
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4" data-testid="text-skills-heading">
              Skills & Contact
            </h2>
            <p className="text-lg text-muted-foreground" data-testid="text-skills-description">
              Technical expertise and how to reach me
            </p>
          </div>
        </ScrollAnimation>

        <div className="grid lg:grid-cols-3 gap-8 mb-16">
          <div className="lg:col-span-2">
            <ScrollAnimation delay={0.2}>
              <h3 className="text-2xl font-semibold mb-6" data-testid="text-skills-technical-heading">
                Technical Skills
              </h3>
            </ScrollAnimation>
            <StaggerContainer className="grid md:grid-cols-2 gap-6" staggerDelay={0.2}>
              {skillCategories.map((category, index) => (
                <StaggerItem key={index}>
                  <Card className="hover-elevate" data-testid={`card-skills-category-${index}`}>
                  <CardHeader className="pb-4">
                    <CardTitle className="flex items-center gap-3 text-lg">
                      <div className="text-primary">{category.icon}</div>
                      {category.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-2">
                      {category.skills.map((skill, skillIndex) => (
                        <Badge key={skillIndex} variant="secondary" data-testid={`badge-skill-${index}-${skillIndex}`}>
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                  </Card>
                </StaggerItem>
              ))}
            </StaggerContainer>
          </div>

          <div>
            <ScrollAnimation delay={0.4}>
              <h3 className="text-2xl font-semibold mb-6" data-testid="text-contact-heading">
                Get In Touch
              </h3>
            </ScrollAnimation>
            <ScrollAnimation delay={0.6}>
              <Card className="hover-elevate" data-testid="card-contact">
              <CardContent className="pt-6">
                <div className="space-y-4">
                  {contactInfo.map((contact, index) => (
                    <div key={index} className="flex items-center gap-3" data-testid={`contact-item-${index}`}>
                      <div className="text-primary">{contact.icon}</div>
                      <div className="flex-1">
                        <p className="font-medium text-sm">{contact.label}</p>
                        <Button
                          variant="ghost"
                          className="p-0 h-auto text-sm text-muted-foreground hover:text-primary justify-start"
                          onClick={() => window.open(contact.link, contact.label === 'Email' || contact.label === 'Phone' ? '_self' : '_blank')}
                          data-testid={`button-contact-${index}`}
                        >
                          {contact.value}
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
                
                <div className="mt-8 pt-6 border-t">
                  <p className="text-sm text-muted-foreground mb-4">
                    Open to new opportunities and collaborations. Let's build something amazing together!
                  </p>
                  <Button 
                    variant="default" 
                    className="w-full gap-2"
                    onClick={() => window.open('mailto:mr.asrathi@gmail.com?subject=Let\'s Connect!')}
                    data-testid="button-contact-cta"
                  >
                    <Mail className="w-4 h-4" />
                    Send Message
                  </Button>
                </div>
              </CardContent>
              </Card>
            </ScrollAnimation>
          </div>
        </div>
      </div>
    </section>
  );
}
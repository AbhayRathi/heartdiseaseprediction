import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ExternalLink, Github, Code } from "lucide-react";
import { ScrollAnimation, StaggerContainer, StaggerItem } from "@/components/ScrollAnimations";

interface Project {
  title: string;
  description: string;
  achievements: string[];
  technologies: string[];
  links?: {
    demo?: string;
    github?: string;
  };
}

const projects: Project[] = [
  {
    title: "Real Estate Agent Platform",
    description: "Full-stack application for Real Estate in the SF Bay Area analyzing and displaying 1,000+ weekly listings",
    achievements: [
      "Built responsive frontend using React.js and TypeScript with custom-styled listing cards",
      "Engineered FastAPI backend with Zillow data integration and BeautifulSoup scrapers",
      "Implemented AI-powered recommendation engine using LLaMA 3 N2 and LangChain",
      "Created modular RAG pipeline for context-aware, agent-like responses",
      "Deployed with Uvicorn and GitHub CI for real-time updates"
    ],
    technologies: ["React.js", "TypeScript", "FastAPI", "LLaMA 3", "LangChain", "FAISS", "Zillow API", "BeautifulSoup"]
  },
  {
    title: "DormNest - SJSU SpartUp Hackathon",
    description: "Web application to streamline school housing process with interactive map and AI-powered features",
    achievements: [
      "Designed interactive frontend with React and TypeScript for apartment exploration",
      "Developed scalable backend using Node.js, Express, and MongoDB",
      "Implemented JWT-based 2-Factor Authentication for security",
      "Integrated OpenAI API for AI-powered search and natural language chatbot"
    ],
    technologies: ["React", "TypeScript", "Node.js", "Express", "MongoDB", "JWT", "OpenAI API", "NLP"]
  },
  {
    title: "Robotic Aerial Vehicle - Real World Design Challenge",
    description: "Designed autonomous UAV for payload delivery, winning 1st place in California and 3rd nationally",
    achievements: [
      "Designed functional UAS model using CAD (Onshape, AutoDesk Fusion 360)",
      "Leveraged AI-driven efficiency testing with predictive modeling in SimFlow",
      "Optimized structure using ANSYS and MATLAB for aerodynamics evaluation",
      "Compiled extensive 80-page design notebook and 100-slide presentation"
    ],
    technologies: ["CAD", "Onshape", "AutoDesk Fusion 360", "ANSYS", "MATLAB", "SimFlow", "AI Modeling"]
  }
];

export default function Projects() {
  return (
    <section className="py-24 px-4 bg-muted/20" id="projects">
      <div className="max-w-6xl mx-auto">
        <ScrollAnimation>
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4" data-testid="text-projects-heading">
              Featured Projects
            </h2>
            <p className="text-lg text-muted-foreground" data-testid="text-projects-description">
              A showcase of my work in AI/ML, full-stack development, and engineering design
            </p>
          </div>
        </ScrollAnimation>

        <StaggerContainer className="grid lg:grid-cols-2 gap-8" staggerDelay={0.3}>
          {projects.map((project, index) => (
            <StaggerItem key={index}>
              <Card className="hover-elevate h-full flex flex-col" data-testid={`card-project-${index}`}>
                <CardHeader>
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <CardTitle className="text-xl mb-2" data-testid={`text-project-title-${index}`}>
                        {project.title}
                      </CardTitle>
                      <p className="text-muted-foreground" data-testid={`text-project-description-${index}`}>
                        {project.description}
                      </p>
                    </div>
                    <Code className="w-6 h-6 text-primary flex-shrink-0" />
                  </div>
                </CardHeader>
                <CardContent className="flex-1 flex flex-col">
                  <ul className="space-y-2 mb-6 flex-1">
                    {project.achievements.map((achievement, achIndex) => (
                      <li key={achIndex} className="text-sm text-muted-foreground flex items-start gap-2" data-testid={`text-project-achievement-${index}-${achIndex}`}>
                        <span className="text-primary mt-1.5 text-xs">▪</span>
                        {achievement}
                      </li>
                    ))}
                  </ul>
                  
                  <div className="space-y-4">
                    <div className="flex flex-wrap gap-2">
                      {project.technologies.map((tech, techIndex) => (
                        <Badge key={techIndex} variant="outline" data-testid={`badge-project-tech-${index}-${techIndex}`}>
                          {tech}
                        </Badge>
                      ))}
                    </div>
                    
                    <div className="flex gap-2">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="gap-2"
                        onClick={() => console.log(`View ${project.title} demo`)}
                        data-testid={`button-project-demo-${index}`}
                      >
                        <ExternalLink className="w-4 h-4" />
                        Demo
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="gap-2"
                        onClick={() => console.log(`View ${project.title} source code`)}
                        data-testid={`button-project-github-${index}`}
                      >
                        <Github className="w-4 h-4" />
                        Code
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </StaggerItem>
          ))}
        </StaggerContainer>
      </div>
    </section>
  );
}
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, MapPin } from "lucide-react";
import { ScrollAnimation, StaggerContainer, StaggerItem } from "@/components/ScrollAnimations";

interface ExperienceItem {
  title: string;
  company: string;
  location: string;
  period: string;
  achievements: string[];
  skills: string[];
}

const experiences: ExperienceItem[] = [
  {
    title: "Machine Learning & Product Growth Intern",
    company: "Playhouse AI",
    location: "Berkeley, CA",
    period: "May 2025 – Present",
    achievements: [
      "Developed and refined AI twin system, boosting session retention by ~20%",
      "Built recommendation models using NLP embeddings and collaborative filtering, improving match relevance by ~18%",
      "Implemented text-based recommendation features increasing group discovery engagement by 30%",
      "Designed growth experiments contributing to 25% MoM increase in college student signups",
      "Helped scale platform to 15,000+ active users with consistent online traction"
    ],
    skills: ["NLP", "OpenAI", "HuggingFace", "LangChain", "Pinecone", "A/B Testing", "Mixpanel"]
  },
  {
    title: "Founding Engineer",
    company: "Stealth Start-Up, Real Estate FinTech",
    location: "San Francisco, CA",
    period: "August 2024 – April 2025",
    achievements: [
      "Created a fintech platform to empower homeowners to buy and sell equity",
      "Utilized MERN stack for listing system with interactive dashboard",
      "Integrated Zillow and Google Maps APIs for real-time property data",
      "Implemented advanced location-based search functionality"
    ],
    skills: ["MERN Stack", "MongoDB", "React.js", "Node.js", "Zillow API", "Google Maps API"]
  },
  {
    title: "AI/ML Development",
    company: "Inspirit AI Scholars Program",
    location: "San Jose, CA",
    period: "June 2023 - August 2023",
    achievements: [
      "Developed facial expression analysis and emotion detection application",
      "Used NLP and ML in Python for visual sentiment analysis model",
      "Trained CNN model on 5,000+ images for emotion recognition",
      "Achieved 80% accuracy using K-Nearest Neighbors algorithm"
    ],
    skills: ["Python", "Computer Vision", "CNN", "NLP", "Machine Learning", "KNN"]
  }
];

export default function Experience() {
  return (
    <section className="py-24 px-4 bg-background" id="experience">
      <div className="max-w-4xl mx-auto">
        <ScrollAnimation>
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4" data-testid="text-experience-heading">
              Professional Experience
            </h2>
            <p className="text-lg text-muted-foreground" data-testid="text-experience-description">
              Building innovative solutions in AI/ML, fintech, and full-stack development
            </p>
          </div>
        </ScrollAnimation>

        <StaggerContainer className="space-y-8" staggerDelay={0.2}>
          {experiences.map((exp, index) => (
            <StaggerItem key={index}>
              <Card className="hover-elevate" data-testid={`card-experience-${index}`}>
                <CardHeader>
                  <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
                    <div className="flex-1">
                      <CardTitle className="text-xl mb-1" data-testid={`text-experience-title-${index}`}>
                        {exp.title}
                      </CardTitle>
                      <p className="text-lg font-medium text-primary mb-2" data-testid={`text-experience-company-${index}`}>
                        {exp.company}
                      </p>
                      <div className="flex flex-col sm:flex-row gap-2 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1" data-testid={`text-experience-location-${index}`}>
                          <MapPin className="w-4 h-4" />
                          {exp.location}
                        </div>
                        <div className="flex items-center gap-1" data-testid={`text-experience-period-${index}`}>
                          <Calendar className="w-4 h-4" />
                          {exp.period}
                        </div>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 mb-4">
                    {exp.achievements.map((achievement, achIndex) => (
                      <li key={achIndex} className="text-sm text-muted-foreground flex items-start gap-2" data-testid={`text-experience-achievement-${index}-${achIndex}`}>
                        <span className="text-primary mt-1.5 text-xs">▪</span>
                        {achievement}
                      </li>
                    ))}
                  </ul>
                  <div className="flex flex-wrap gap-2">
                    {exp.skills.map((skill, skillIndex) => (
                      <Badge key={skillIndex} variant="secondary" data-testid={`badge-experience-skill-${index}-${skillIndex}`}>
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </StaggerItem>
          ))}
        </StaggerContainer>
      </div>
    </section>
  );
}
import Experience from '../Experience';

export default function ExperienceExample() {
  return <Experience />;
}
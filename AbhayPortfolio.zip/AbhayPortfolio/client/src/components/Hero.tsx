import { Button } from "@/components/ui/button";
import { Github, Linkedin, Mail, Phone } from "lucide-react";
import headshotUrl from "@assets/generated_images/Professional_headshot_portrait_f28eafff.png";
import { ScrollAnimation, StaggerContainer, StaggerItem } from "@/components/ScrollAnimations";

export default function Hero() {
  return (
    <section className="min-h-screen flex items-center justify-center px-4 py-16 bg-background">
      <div className="max-w-4xl mx-auto text-center">
        <StaggerContainer className="mb-8">
          <StaggerItem direction="fade">
            <img
              src={headshotUrl}
              alt="Abhay Rathi"
              className="w-40 h-40 md:w-48 md:h-48 rounded-full mx-auto mb-6 border-4 border-primary/10"
              data-testid="img-hero-headshot"
            />
          </StaggerItem>
          <StaggerItem>
            <h1 className="text-3xl md:text-4xl lg:text-6xl font-bold mb-4 text-foreground" data-testid="text-hero-name">
              Abhay Rathi
            </h1>
          </StaggerItem>
          <StaggerItem>
            <p className="text-lg md:text-xl lg:text-2xl text-muted-foreground mb-2" data-testid="text-hero-title">
              Software Engineer & AI/ML Developer
            </p>
          </StaggerItem>
          <StaggerItem>
            <p className="text-base md:text-lg text-muted-foreground mb-8 px-4" data-testid="text-hero-subtitle">
              Computer Engineering Student at SJSU • ML & Product Growth Intern at Playhouse AI
            </p>
          </StaggerItem>
        </StaggerContainer>
        
        <ScrollAnimation delay={0.5}>
          <div className="flex flex-col sm:flex-row flex-wrap justify-center gap-4 mb-8">
            <Button 
              variant="default" 
              size="lg" 
              className="gap-2 w-full sm:w-auto"
              onClick={() => window.open('mailto:mr.asrathi@gmail.com')}
              data-testid="button-contact-email"
            >
              <Mail className="w-5 h-5" />
              Contact Me
            </Button>
            <Button 
              variant="outline" 
              size="lg" 
              className="gap-2 w-full sm:w-auto"
              onClick={() => window.open('/api/resume/download', '_blank')}
              data-testid="button-download-resume"
            >
              Download Resume
            </Button>
          </div>
        </ScrollAnimation>

        <ScrollAnimation delay={0.7}>
          <div className="flex justify-center gap-6">
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => window.open('https://linkedin.com/in/abhay-rathi', '_blank')}
              data-testid="button-social-linkedin"
            >
              <Linkedin className="w-5 h-5" />
            </Button>
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => window.open('https://github.com/AbhayRathi', '_blank')}
              data-testid="button-social-github"
            >
              <Github className="w-5 h-5" />
            </Button>
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => window.open('tel:+19258045462')}
              data-testid="button-social-phone"
            >
              <Phone className="w-5 h-5" />
            </Button>
          </div>
        </ScrollAnimation>
      </div>
    </section>
  );
}
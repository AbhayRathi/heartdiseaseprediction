import { Card, CardContent } from "@/components/ui/card";
import { GraduationCap, MapPin, User } from "lucide-react";
import { ScrollAnimation, StaggerContainer, StaggerItem } from "@/components/ScrollAnimations";

export default function About() {
  return (
    <section className="py-24 px-4 bg-muted/20" id="about">
      <div className="max-w-4xl mx-auto">
        <ScrollAnimation>
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4" data-testid="text-about-heading">
              About Me
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto" data-testid="text-about-description">
              I'm a passionate Computer Engineering student with a focus on AI/ML and full-stack development. 
              Currently contributing to innovative products that impact thousands of users.
            </p>
          </div>
        </ScrollAnimation>

        <StaggerContainer className="grid md:grid-cols-3 gap-8" staggerDelay={0.2}>
          <StaggerItem>
            <Card className="text-center hover-elevate" data-testid="card-about-background">
              <CardContent className="pt-6">
                <User className="w-12 h-12 mx-auto mb-4 text-primary" />
                <h3 className="font-semibold mb-2">Background</h3>
                <p className="text-sm text-muted-foreground">
                  Experienced in building scalable applications, AI systems, and leading engineering teams. 
                  Passionate about creating technology that makes a real impact.
                </p>
              </CardContent>
            </Card>
          </StaggerItem>

          <StaggerItem>
            <Card className="text-center hover-elevate" data-testid="card-about-education">
              <CardContent className="pt-6">
                <GraduationCap className="w-12 h-12 mx-auto mb-4 text-primary" />
                <h3 className="font-semibold mb-2">Education</h3>
                <p className="text-sm text-muted-foreground">
                  B.S. Computer Engineering at San Jose State University. 
                  Continuously learning and staying updated with the latest technologies.
                </p>
              </CardContent>
            </Card>
          </StaggerItem>

          <StaggerItem>
            <Card className="text-center hover-elevate" data-testid="card-about-location">
              <CardContent className="pt-6">
                <MapPin className="w-12 h-12 mx-auto mb-4 text-primary" />
                <h3 className="font-semibold mb-2">Location</h3>
                <p className="text-sm text-muted-foreground">
                  Based in San Ramon, California. Open to opportunities in the SF Bay Area 
                  and remote collaboration.
                </p>
              </CardContent>
            </Card>
          </StaggerItem>
        </StaggerContainer>
      </div>
    </section>
  );
}
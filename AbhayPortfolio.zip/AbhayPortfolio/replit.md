# Portfolio Website

## Overview

This is a modern developer portfolio website built for Abhay Rathi, a Computer Engineering student and ML & Product Growth Intern at Playhouse AI. The application showcases his experience, projects, skills, and provides a professional contact form. The website follows modern design principles with clean typography, strategic use of whitespace, and professional aesthetics inspired by Linear, GitHub profiles, and Vercel's design language.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The frontend is built as a single-page application (SPA) using React with TypeScript, providing a smooth user experience with client-side routing via Wouter. The architecture emphasizes component modularity and reusability:

- **Component Structure**: Organized into feature-based components (Hero, About, Experience, Projects, Skills, ContactForm) with shared UI components from shadcn/ui
- **State Management**: Uses React hooks for local state management and TanStack Query for server state management
- **Styling**: Tailwind CSS with custom design system implementation including dark/light theme support
- **Animations**: Framer Motion integration for scroll-triggered animations and smooth transitions
- **Type Safety**: Full TypeScript implementation across all components

### Backend Architecture
The backend follows a RESTful API design pattern using Express.js with TypeScript:

- **Server Framework**: Express.js with middleware for JSON parsing, URL encoding, and request logging
- **API Design**: RESTful endpoints for contact form submission and resume downloads
- **Error Handling**: Centralized error handling middleware with proper HTTP status codes
- **File Serving**: Static file serving for resume downloads from attached assets

### Data Storage Solutions
The application uses a dual storage approach with future database scalability:

- **Development Storage**: In-memory storage implementation for rapid development and testing
- **Database Schema**: PostgreSQL schema defined using Drizzle ORM with tables for users and contact submissions
- **Data Models**: Zod schemas for runtime validation and type safety
- **Migration Support**: Drizzle Kit configuration for database migrations and schema management

### Authentication and Authorization Mechanisms
Currently implements a basic user system foundation:

- **User Schema**: Defined user table with username and password fields
- **Session Management**: Placeholder for connect-pg-simple session store integration
- **Future Implementation**: Ready for JWT or session-based authentication expansion

### External Dependencies

#### Design System and UI Components
- **shadcn/ui**: Comprehensive component library built on Radix UI primitives
- **Tailwind CSS**: Utility-first CSS framework for responsive design
- **Radix UI**: Unstyled, accessible UI primitives for complex components
- **Framer Motion**: Animation library for scroll animations and micro-interactions

#### Development and Build Tools
- **Vite**: Modern build tool with fast HMR and optimized production builds
- **TypeScript**: Type safety and enhanced developer experience
- **ESBuild**: Fast JavaScript bundler for server-side code
- **PostCSS**: CSS processing with Tailwind integration

#### Database and ORM
- **Drizzle ORM**: Type-safe SQL query builder and migration tool
- **Neon Database**: PostgreSQL-compatible serverless database (via @neondatabase/serverless)
- **Zod**: Runtime type validation and schema definition

#### External APIs and Services
- **Contact Form Processing**: Server-side form handling with validation
- **Resume Download**: File serving capability for PDF resume downloads
- **Font Integration**: Google Fonts (Inter, JetBrains Mono, DM Sans, Fira Code, Geist Mono, Architects Daughter)

#### Deployment and Environment
- **Replit Integration**: Development environment with runtime error overlay
- **Environment Variables**: DATABASE_URL configuration for database connectivity
- **Static Asset Management**: Organized asset serving for images and documents
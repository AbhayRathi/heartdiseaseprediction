# Portfolio Website Design Guidelines

## Design Approach
**Reference-Based Approach**: Drawing inspiration from modern developer portfolios like Linear, GitHub profiles, and Vercel's design language. Focus on clean typography, strategic use of whitespace, and subtle visual hierarchy that lets content shine.

## Core Design Elements

### Color Palette
**Light Mode:**
- Primary: 15 12% 15% (charcoal for text)
- Secondary: 220 13% 69% (muted blue-gray for supporting text)
- Background: 0 0% 98% (off-white)
- Accent: 217 91% 60% (professional blue for links/CTAs)

**Dark Mode:**
- Primary: 210 40% 98% (near-white text)
- Secondary: 215 16% 65% (muted gray for supporting text)  
- Background: 222 47% 11% (dark navy)
- Accent: 217 91% 70% (lighter blue for dark mode)

### Typography
- **Primary**: Inter (Google Fonts) - clean, professional sans-serif
- **Accent**: JetBrains Mono (Google Fonts) - for code snippets and technical details
- **Hierarchy**: Large hero text (3xl-4xl), section headers (2xl), body text (base-lg)

### Layout System
**Spacing**: Consistent use of Tailwind units: 4, 6, 8, 12, 16, 24 for margins/padding
**Grid**: Single column on mobile, strategic two-column layouts on desktop for experience/projects

### Component Library
- **Navigation**: Fixed header with smooth scroll links
- **Cards**: Clean project/experience cards with subtle shadows and hover states
- **Buttons**: Primary filled buttons for main CTAs, outline buttons for secondary actions
- **Typography**: Consistent heading hierarchy with proper spacing
- **Sections**: Clear visual separation with generous whitespace

## Layout Structure (5 Sections)

1. **Hero Section**: Name, title, brief intro with professional headshot
2. **About**: Personal background, education, interests 
3. **Experience**: Timeline of roles at Playhouse AI and Stealth Start-Up
4. **Projects**: Featured work including Real Estate Agent platform, DormNest
5. **Contact/Skills**: Technical stack and contact information

## Images
- **Professional headshot** in hero section (circular crop, 200px diameter)
- **Project screenshots** for portfolio items (16:9 aspect ratio, max 600px wide)
- **No large hero background image** - keeping focus on content and readability

## Visual Treatment
- **Minimal animations**: Subtle fade-ins on scroll, gentle hover states
- **Clean sections**: Generous padding between sections (py-16 to py-24)
- **Professional tone**: Sophisticated color palette avoiding bright/flashy colors
- **Responsive design**: Mobile-first approach with thoughtful desktop enhancements
- **Accessibility**: High contrast ratios, readable font sizes, proper semantic structure

## Key Design Principles
- **Content-first**: Typography and readability prioritized over decorative elements
- **Professional polish**: Clean, modern aesthetic suitable for developer roles
- **Performance-focused**: Minimal assets, optimized images, clean code structure
- **Scannable**: Clear visual hierarchy allowing recruiters to quickly find key information
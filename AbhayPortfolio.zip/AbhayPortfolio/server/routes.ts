import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertContactSchema } from "@shared/schema";
import path from "path";

export async function registerRoutes(app: Express): Promise<Server> {
  // Contact form submission
  app.post("/api/contact", async (req, res) => {
    try {
      const contactData = insertContactSchema.parse(req.body);
      const submission = await storage.createContactSubmission(contactData);
      
      res.json({ 
        success: true, 
        message: "Contact form submitted successfully",
        id: submission.id
      });
    } catch (error) {
      console.error("Contact form submission error:", error);
      res.status(400).json({ 
        success: false, 
        message: "Failed to submit contact form" 
      });
    }
  });

  // Download resume endpoint
  app.get("/api/resume/download", (req, res) => {
    const resumePath = path.join(process.cwd(), "attached_assets", "Abhay_Rathi_Resume_1758003873915.pdf");
    
    res.download(resumePath, "Abhay_Rathi_Resume.pdf", (err) => {
      if (err) {
        console.error("Resume download error:", err);
        res.status(404).json({ error: "Resume file not found" });
      }
    });
  });

  const httpServer = createServer(app);

  return httpServer;
}
